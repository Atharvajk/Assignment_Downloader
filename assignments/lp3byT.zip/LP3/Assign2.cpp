#include <bits/stdc++.h>
using namespace std;
#define max_size 100

class HuffmanTreeNode
{
public:
    char data;
    int freq;
    HuffmanTreeNode *left;
    HuffmanTreeNode *right;

    HuffmanTreeNode(char character, int frequency)
    {
        data = character;
        freq = frequency;
        left = right = NULL;
    }
};

class Compare
{
public:
    bool operator()(HuffmanTreeNode *a, HuffmanTreeNode *b)
    {
        return a->freq > b->freq;
    }
};

HuffmanTreeNode *generateTree(priority_queue<HuffmanTreeNode *, vector<HuffmanTreeNode *>, Compare> pq)
{
    while (pq.size() != 1)
    {
        HuffmanTreeNode *left = pq.top();
        pq.pop();
        HuffmanTreeNode *right = pq.top();
        pq.pop();

        HuffmanTreeNode *node = new HuffmanTreeNode('$', left->freq + right->freq);

        node->left = left;
        node->right = right;

        pq.push(node);
    }
    return pq.top();
}

void printcodes(HuffmanTreeNode *root, vector<int> arr, int top)
{
    if (root->left)
    {
        arr[top] = 0;
        printcodes(root->left, arr, top + 1);
    }
    if (root->right)
    {
        arr[top] = 1;
        printcodes(root->right, arr, top + 1);
    }
    if (!root->left && !root->right)
    {
        cout << root->data << " ";
        for (int i = 0; i < top; i++)
        {
            cout << arr[i];
        }
        cout << endl;
    }
}
void HuffmanCodes(vector<char> data, vector<int> freq)
{
    priority_queue<HuffmanTreeNode *, vector<HuffmanTreeNode *>, Compare> pq;

    int size = data.size();
    for (int i = 0; i < size; i++)
    {
        HuffmanTreeNode *newnode = new HuffmanTreeNode(data[i], freq[i]);
        pq.push(newnode);
    }

    HuffmanTreeNode *root = generateTree(pq);

    vector<int> arr(max_size);
    int top = 0;

    printcodes(root, arr, top);
}

int main()
{
    cout << "Enter the number of characters : " << endl;
    int n;
    cin >> n;

    vector<char> data;
    vector<int> freq;
    char x;
    cout << "Enter the characters : " << endl;
    for (int i = 0; i < n; i++)
    {
        cin >> x;
        data.push_back(x);
    }
    int y;
    cout << "Enter the freq of the characters : " << endl;
    for (int i = 0; i < n; i++)
    {
        cin >> y;
        freq.push_back(y);
    }

    HuffmanCodes(data, freq);

    return 0;
}
/*6
a b c d e f
5 9 12 13 16 45
f 0
c 100
d 101
a 1100
b 1101
e 111*/