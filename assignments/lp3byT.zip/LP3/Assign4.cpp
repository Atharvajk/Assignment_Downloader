#include <bits/stdc++.h>
using namespace std;
int cnt = 0;

bool issafe(int r, int c, vector<vector<int>> &board, int n)
{
    int i = r;
    int j = c;

    // upper left

    while (i >= 0 && j >= 0)
    {
        if (board[i][j] == 1)
        {
            return false;
        }
        i--;
        j--;
    }

    i = r;
    j = c;

    // lower left
    while (i < n && j >= 0)
    {
        if (board[i][j] == 1)
        {
            return false;
        }
        i++;
        j--;
    }

    i = r;
    j = c;

    // left
    while (j >= 0)
    {
        if (board[i][j] == 1)
        {
            return false;
        }
        j--;
    }

    i = r;
    j = c;

    // upper right

    while (i >= 0 && j < n)
    {
        if (board[i][j] == 1)
        {
            return false;
        }
        i--;
        j++;
    }

    i = r;
    j = c;
    // lower right

    while (i < n && j < n)
    {
        if (board[i][j] == 1)
        {
            return false;
        }
        i++;
        j++;
    }
    i = r;
    j = c;

    // right

    while (j < n)
    {
        if (board[i][j] == 1)
        {
            return false;
        }
        j++;
    }

    return true;
}

void solve(int col, int col1, vector<vector<int>> &board, int n)
{
    if (col == n)
    {
        cnt++;
        for (auto c : board)
        {
            for (auto x : c)
            {
                cout << x;
            }
            cout << endl;
        }
        cout << endl;
    }

    if (col == col1)
    {
        solve(col + 1, col1, board, n);
    }

    for (int i = 0; i < n; i++)
    {
        if (issafe(i, col, board, n))
        {
            board[i][col] = 1;
            solve(col + 1, col1, board, n);
            board[i][col] = 0;
        }
    }
}
int main()
{
    int n;
    cout << "Enter the size of nxn matrix : " << endl;
    cin >> n;

    if (n < 4)
    {
        cout << "No solutions possible !!" << endl;
    }
    int row;
    int col;

    vector<vector<int>> board(n, vector<int>(n, 0));
    cout << "Enter the coordinates where first queen will be placed : " << endl;
    cout << "Enter the row number : " << endl;
    cin >> row;
    cout << "Enter the col number : " << endl;
    cin >> col;

    board[row][col] = 1;

    solve(0, col, board, n);

    if (cnt == 0)
    {
        cout << "No solutions possible" << endl;
    }
    return 0;
}