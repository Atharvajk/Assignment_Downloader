#include <bits/stdc++.h>
using namespace std;

class Fibonacci
{
public:
    int n;
    vector<int> memo;

    Fibonacci(int n)
    {
        this->n = n;
        memo.resize(n + 1, -1);
    }

    int recursive(int i)
    {
        if (i <= 1)
        {
            return i;
        }
        if (memo[i] != -1)
        {
            return memo[i];
        }

        return memo[i] = recursive(i - 1) + recursive(i - 2);
    }

    void iterative()
    {
        int t1 = 0;
        int t2 = 1;
        int nextterm = 0;

        for (int i = 1; i <= n; i++)
        {
            if (i == 1)
            {
                cout << t1 << " ";
                continue;
            }
            if (i == 2)
            {
                cout << t2 << " ";
                continue;
            }
            nextterm = t1 + t2;
            t1 = t2;
            t2 = nextterm;
            cout << nextterm << " ";
        }
        cout << endl;
    }
};
int main()
{
    int n;
    cout << "Enter the number of terms in fibonacci series : " << endl;
    cin >> n;

    Fibonacci fb(n);

    cout << "Iterative Fibonacci output : " << endl;
    fb.iterative();
    cout << endl;

    cout << "Recursive Fibonacci output : " << endl;
    for (int i = 0; i < n; i++)
    {
        cout << fb.recursive(i) << " ";
    }

    return 0;
}